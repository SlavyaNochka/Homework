|Номер задания|Команды|Описание|Ключ|
|-------------|-------|--------|----|
|1|ls <br> cat |ls - список файлов в данной директории <br> cat <name> - открыть файл | ZGFpejZhaFJhZVNhZXhhaWJ1YWYK |
|2| cat ./* |отображение всей информации |dGhlaWxpM2FoWm9odGFpM2VldzMK |
|3| while read $LINE; do echo $LINE; done <./-diary.txt-;| построчно вывели файл | Y284ZWlxdXVlMmllTDNpZXBoNWUK |
|14| cd <br> ls | cd <path> - переход в директорию | d2FodmFoMWFlV2FpYmVlaG9vMmIK |
|15| ls|ls .. - список файлов на уровне выше | TWVlMXdvaDJ6YWVoZWoyamllNm8K |
|16|id |  данные о пользователе| ZXVsb29naG91MFBob2g4T2hkYWkK |
|17|  ls -a| флаг -a показывает скрытые файлы | bmVlNm1lMEhhaU11M2thaGVpNmEK |
|18| man | Документация по команде | Y2hpZWNoM2VpRzRJZWtlaXNlbGUK |
|19| mkdir -p | создает ветку директорий| V2VpMGNvaHNoZWlxdWE0YWhnaG8K |
|20| rm -r | Чтобы удалить папку со всем ее содержимым | YW1pZWhpaW0yb2h5NW9vRjZlaXcK |
|21| 1)rm [0-9].txt <br>2)rm [a-z].png <br>3)rm test-*.log <br>ls| C помощью регулярных выражений удаляем нужные нам файлы | aWU0b29XdWxlaXBodXBpZWZveW8K |
|22|i=1; while [ $i -lt 999 ];do touch $i.txt;let i++;done; <br> | touch - создает файл <br> let i++ увеличивает счетчик на единицу| dXI2dXNhaDNvaFQxaWV2MGNobzgK |
|23| ls <br> cd <br> mv <br>| mv - перемещает или меняет название файла|dmVlc2VpQzVBb2dlaXI1cmVlM2YK |
|24| ls, cd и cp -r | cp -r - копирует каталог | YWVnaG9venVvejd2b292OHNvaEwK |
|25| ls <br> cat| None | dGhlZThhcXVpZUNpTGFpdGhlZTkK|
|26| less | отображение содержимого файла по страницам | WWVpc2gxYWlndXVrZWl5ZWloaWUK |
|27|tail -f |  позволяет выводить заданное количество строк с конца файла, а также выводить новые строки в интерактивном режиме |dGVlMUtleThhUXVvaDFnZTFiaWkK |
|28| cat >diary <<EOF <br> echo -n '11:32pm: Нассал под кресло. Еееееееее!' >> diary| вставили весь текст, кроме последнего предложения, т.к появляется лишний Enter.Затем через echo вставили недостающий фрагмент. | ZWV4b1g1WnVkMm9oZnVjYWhkdTMK|
|29| None | нажимаем стрелочку вверх, чтобы узнать какие команды были использованы |dmFvbmcwcGFlMWlodUJvaFppZWQK |
